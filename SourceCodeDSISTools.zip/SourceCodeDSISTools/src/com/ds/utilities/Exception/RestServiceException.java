package com.ds.utilities.Exception;

public class RestServiceException extends Exception {

	private static final long serialVersionUID = -1082845444352731277L;
	
	public RestServiceException(Throwable e) {
		super(e);
	}

}
