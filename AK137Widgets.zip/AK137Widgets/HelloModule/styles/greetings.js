define(function() {
	return {
		name: 'Rob',
		sayHello: function() {
			console.log("Hii my name is Garvita")
		}
	}

});


