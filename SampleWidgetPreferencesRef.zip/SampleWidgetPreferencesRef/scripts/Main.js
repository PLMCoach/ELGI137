function executeWidgetCode() {
	require([], function() {
		var myWidget = {
			onLoadWidget: function() {
				
				// Add new preference - userLocation
				widget.addPreference({
					name: "userLocation",
					type: "text",
					label: "User Location",
					defaultValue: ""
				});
				
				// Add new preference - userDOB
				widget.addPreference({
					name: "userDOB",
					type: "hidden",
					label: "User Date of Birth",
					defaultValue: ""
				});
				// Define content to be displayed inside widget
				widget.body.innerHTML = "<br/> <br/>"+ "<p> Welcome to 3DExperience Platform " +  widget.getPreference("userName").value + " ...!!! </p>" + "<br/> <br/>" 
				+ "<p> User Account Status is : " + widget.getValue("3DExpAccountCheck") + "</p>" + "<br/> <br/>" 
				+ "<p> User Role is : " + widget.getValue("userRole") + "</p>" + "<br/> <br/>" 
				+ "<p> User Location is : " + widget.getValue("userLocation") + "</p>" + "<br/> <br/>"
				+ "<p> User Job Level is : " + widget.getValue("limit") + "</p>" + "<br/> <br/>"
				+ "<p> User Date of Birth is : " + widget.getValue("userDOB") + "</p>" + "<br/> <br/>";
			}
			
		};

		// Add onLoad event
		widget.addEvent("onLoad", myWidget.onLoadWidget);
	});
}
