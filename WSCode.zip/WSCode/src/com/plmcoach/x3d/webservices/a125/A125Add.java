package com.plmcoach.x3d.webservices.a125;

import com.dassault_systemes.platform.restServices.RestService;
import javax.json.Json;
import javax.json.JsonObjectBuilder;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path; 
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/add")
@Produces("application/json")
public class A125Add extends RestService {
	
	@GET
	public Response addFunction(@javax.ws.rs.core.Context HttpServletRequest request,@QueryParam("num1") String num1,@QueryParam("num2") String num2)
	{
		float val1, val2, result;
		JsonObjectBuilder output =  Json.createObjectBuilder();
		
		try {
			val1 = Float.parseFloat(num1);
			val2 = Float.parseFloat(num2);
			
			result = val1+val2;
			
			output.add("msg", "OK");
			output.add("result", result);
			
		} catch (Exception e) {
			System.out.println("Error: " + e);
			return Response.status(401).entity("Error").build();
		}
		String outputArray = output.build().toString();
		return Response.status(200).entity(outputArray).build();
	}

}