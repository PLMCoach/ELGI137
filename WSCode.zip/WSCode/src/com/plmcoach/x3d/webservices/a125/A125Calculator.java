package com.plmcoach.x3d.webservices.a125;

// Dependent JAR Paths
// C:\DassaultSystemes\R2022x\3DSpace\win_b64\code\tomee\webapps\3dspace\WEB-INF\lib
// C:\DassaultSystemes\R2022x\3DSpace\win_b64\code\tomee\lib

import com.dassault_systemes.platform.restServices.ModelerBase; 
import javax.ws.rs.ApplicationPath;

@ApplicationPath("/A125Calculator")
public class A125Calculator extends ModelerBase {
	
	public Class<?>[] getServices(){
		return new Class[] {A125Add.class};
	}

}
